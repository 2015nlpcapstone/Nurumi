var searchData=
[
  ['bitmap',['bitmap',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_m_keyboard_view.html#a3d53f85ae53388c9a46280fe02fa719b',1,'com::fouram::nurumikeyboard::NurumiIME::MKeyboardView']]],
  ['bok_5fja_5feum_5fjong_5fseong',['bok_ja_eum_jong_seong',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_i_m_e___automata_1_1_automata__type___kor__3.html#a5467b783a01561b18a7c2a148ffd20a5',1,'com::fouram::nurumikeyboard::IME_Automata::Automata_type_Kor_3']]],
  ['buffer',['buffer',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_i_m_e___automata_1_1_automata__type___kor__1.html#a2648e6a0de41a0d9f63a9ce8fd02250f',1,'com.fouram.nurumikeyboard.IME_Automata.Automata_type_Kor_1.buffer()'],['../classcom_1_1fouram_1_1nurumikeyboard_1_1_i_m_e___automata_1_1_automata__type___kor__2.html#abb8fb4704d0f6440ec8774a4ddf964c1',1,'com.fouram.nurumikeyboard.IME_Automata.Automata_type_Kor_2.buffer()'],['../classcom_1_1fouram_1_1nurumikeyboard_1_1_i_m_e___automata_1_1_automata__type___kor__3.html#a5be366de4afc4f2afafc80513cd046f7',1,'com.fouram.nurumikeyboard.IME_Automata.Automata_type_Kor_3.buffer()']]]
];
