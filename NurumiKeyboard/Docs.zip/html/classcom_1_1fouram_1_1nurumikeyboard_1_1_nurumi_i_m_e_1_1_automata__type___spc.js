var classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___spc =
[
    [ "execute", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___spc.html#af93028f1262534060b35f308e2488d48", null ],
    [ "MODE_SPECIAL", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___spc.html#a9b1dd36290e2e343cc1ef92ddfec7b41", null ],
    [ "count_finger", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___spc.html#a1d03a1e9b785be25d98a568ab75db8ea", null ],
    [ "DIRECTION_DOT", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___spc.html#a1bf271f45db2c30c87c7f57ea8e2812c", null ],
    [ "DIRECTION_DOWN", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___spc.html#a53c35ee90e64da7ead58c16f567953de", null ],
    [ "DIRECTION_EMPTY", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___spc.html#a4798629c3bb534b9091452c77350a845", null ],
    [ "DIRECTION_LEFT", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___spc.html#acace1b2d2f46581c7f36749e1aeaf592", null ],
    [ "DIRECTION_RIGHT", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___spc.html#a983cf7e2369a73d1f6d921d727239c8a", null ],
    [ "DIRECTION_UP", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___spc.html#a1cfd888596c4dccef3928e3ce9b34dd7", null ],
    [ "finger", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___spc.html#a75b6613426b7d1ef4902795ac5342b0f", null ],
    [ "ic", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___spc.html#a11962f75a0252fcc500c77cc0ca3f79d", null ],
    [ "INDEX_FINGER", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___spc.html#ae81661a0db6c0cc8502c4c4a64d33096", null ],
    [ "MIDLE_FINGER", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___spc.html#a309b89771cffdf32ce0499b1e8fc1868", null ],
    [ "PINKY_FINGER", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___spc.html#a53ae95bbfa4f266d56f21baaa2e59765", null ],
    [ "RING__FINGER", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___spc.html#abee171e8c07fb02cb547b77cb031823d", null ],
    [ "str_to_write", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___spc.html#a0695f7cbc8966fc4525219cce0128782", null ],
    [ "THUMB_FINGER", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___spc.html#a72e9f5dd807217bd781373d5ec91f466", null ]
];