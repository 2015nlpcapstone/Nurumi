var classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_setting_activity =
[
    [ "onCreate", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_setting_activity.html#ac9db0a5536dab7c9e194e5dd4fcecb74", null ],
    [ "onDestroy", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_setting_activity.html#aed94e8ead9e0c471f18f9bf8178a4213", null ],
    [ "setOnPreferenceChange", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_setting_activity.html#a13c8914e384cd77a59ac5967620d6ce8", null ],
    [ "onPreferenceChangeListener", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_setting_activity.html#adc752fbbd895f4a9e23e206722283f21", null ]
];