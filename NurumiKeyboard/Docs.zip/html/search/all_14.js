var searchData=
[
  ['wisp_5fflare',['WISP_FLARE',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_korean_advanced_natartgul.html#a8014bb2c8c9ff4d6f2319bdf2312b8db',1,'kookmin.cs.fouram.nurumikeyboard.automata.KoreanAdvancedNatartgul.WISP_FLARE()'],['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_korean_naratgul.html#a1f9d260f5edad027fec7449383f62abd',1,'kookmin.cs.fouram.nurumikeyboard.automata.KoreanNaratgul.WISP_FLARE()']]]
];
