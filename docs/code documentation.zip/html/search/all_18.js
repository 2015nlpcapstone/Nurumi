var searchData=
[
  ['zero',['Zero',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_special_characters.html#ae25d2d35138ad361e9e6f31fcd326064',1,'kookmin::cs::fouram::nurumikeyboard::automata::SpecialCharacters']]]
];
