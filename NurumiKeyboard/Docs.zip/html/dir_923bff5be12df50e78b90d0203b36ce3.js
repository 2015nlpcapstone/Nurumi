var dir_923bff5be12df50e78b90d0203b36ce3 =
[
    [ "InformationActivity.java", "_information_activity_8java.html", [
      [ "InformationActivity", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_information_activity.html", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_information_activity" ]
    ] ],
    [ "MKeyboardView.java", "_m_keyboard_view_8java.html", [
      [ "MKeyboardView", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_m_keyboard_view.html", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_m_keyboard_view" ],
      [ "CircleLinkedWithPtId", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_m_keyboard_view_1_1_circle_linked_with_pt_id.html", null ],
      [ "PtIdLinkedWithPtIndex", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_m_keyboard_view_1_1_pt_id_linked_with_pt_index.html", null ]
    ] ],
    [ "NurumiIME.java", "_nurumi_i_m_e_8java.html", [
      [ "NurumiIME", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_nurumi_i_m_e.html", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_nurumi_i_m_e" ]
    ] ],
    [ "OnMKeyboardGestureListener.java", "_on_m_keyboard_gesture_listener_8java.html", [
      [ "OnMKeyboardGestureListener", "interfacecom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_on_m_keyboard_gesture_listener.html", "interfacecom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_on_m_keyboard_gesture_listener" ]
    ] ],
    [ "SettingActivity.java", "_setting_activity_8java.html", [
      [ "SettingActivity", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_setting_activity.html", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_setting_activity" ]
    ] ]
];