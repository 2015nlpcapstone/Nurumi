var classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1korean_character_1_1_korean_character =
[
    [ "KoreanCharacter", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1korean_character_1_1_korean_character.html#a8c91f98e4e8271856f17490dba446ee9", null ],
    [ "getCharNum", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1korean_character_1_1_korean_character.html#a080ef0b2508c2d8835fa45dec115a9b7", null ],
    [ "getName", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1korean_character_1_1_korean_character.html#a05d2b46378ef8478f257c5dd87c51963", null ],
    [ "getUnicode", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1korean_character_1_1_korean_character.html#a7d774b59b756bacf168cd86c8db8d46e", null ],
    [ "setUnicode", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1korean_character_1_1_korean_character.html#abe85bcdeb700f5cfeb7ae5f35b2cfb56", null ],
    [ "name", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1korean_character_1_1_korean_character.html#ac6bc1485932d3cfbad20e7b653ca7684", null ],
    [ "unicode", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1korean_character_1_1_korean_character.html#a698fde917e129e4d5d6733c36739566f", null ]
];