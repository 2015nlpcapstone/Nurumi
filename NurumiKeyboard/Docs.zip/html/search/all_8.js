var searchData=
[
  ['jong_5fseong',['JONG_SEONG',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___kor__1.html#a7313e83bbc45f385fabbe273602ffb68',1,'com.fouram.nurumikeyboard.NurumiIME.Automata_type_Kor_1.JONG_SEONG()'],['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___kor__3.html#a1c9c464bb47fa440d6a93f6af1888417',1,'com.fouram.nurumikeyboard.NurumiIME.Automata_type_Kor_3.JONG_SEONG()']]],
  ['jong_5fseong_5fjaeum',['JONG_SEONG_JAEUM',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___kor__1.html#a56e2bd8d9cf53e73aa17ea48aa37a1b2',1,'com::fouram::nurumikeyboard::NurumiIME::Automata_type_Kor_1']]],
  ['jung_5fseong',['JUNG_SEONG',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___kor__1.html#a892bb2a138e664eafffc4325fa2bb4d6',1,'com.fouram.nurumikeyboard.NurumiIME.Automata_type_Kor_1.JUNG_SEONG()'],['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___kor__3.html#a5594dd13ca7aac011302bc7afd7f1fd5',1,'com.fouram.nurumikeyboard.NurumiIME.Automata_type_Kor_3.JUNG_SEONG()']]],
  ['jung_5fseong_5fmoeum',['JUNG_SEONG_MOEUM',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___kor__1.html#aed0cb2c1603ac9cce47648b23482b870',1,'com::fouram::nurumikeyboard::NurumiIME::Automata_type_Kor_1']]]
];
