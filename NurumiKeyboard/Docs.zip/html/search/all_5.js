var searchData=
[
  ['finger',['finger',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___eng.html#a6f3f8a31dd6325b9493718c9ef9ab013',1,'com.fouram.nurumikeyboard.NurumiIME.Automata_type_Eng.finger()'],['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___kor__1.html#af9bdea22f3e3b4a4f72f71170f4235f2',1,'com.fouram.nurumikeyboard.NurumiIME.Automata_type_Kor_1.finger()'],['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___kor__3.html#a5f67b35cec36d4ff94b0c0cc6c6d6ecc',1,'com.fouram.nurumikeyboard.NurumiIME.Automata_type_Kor_3.finger()']]],
  ['firstjaeum_5fbokjaeum',['firstjaeum_bokjaeum',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___kor__1.html#a39bbff1ac8c602c3ea8fd755da161b42',1,'com::fouram::nurumikeyboard::NurumiIME::Automata_type_Kor_1']]],
  ['five_5ffingers',['FIVE_FINGERS',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_nurumi_i_m_e.html#a9b39dd4573a5446f50b56ae0f0beba4d',1,'com::fouram::nurumikeyboard::NurumiIME::NurumiIME']]],
  ['font_5fsize',['FONT_SIZE',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_m_keyboard_view.html#a23e5ec95ccc9a2521f46ce31484af10e',1,'com::fouram::nurumikeyboard::NurumiIME::MKeyboardView']]],
  ['fontsize',['fontSize',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_m_keyboard_view.html#a4e8a715c36ff3c2971a6f3dd31a72d09',1,'com::fouram::nurumikeyboard::NurumiIME::MKeyboardView']]]
];
