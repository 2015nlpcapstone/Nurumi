var searchData=
[
  ['restart',['restart',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_nurumi_i_m_e.html#a7f70e8d5f0568ea732b5d43d59289a69',1,'kookmin::cs::fouram::nurumikeyboard::inputmethod::NurumiIME']]],
  ['restartmng',['restartMng',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_nurumi_i_m_e.html#a260f598785fc224c0d5b6db3df40d6d9',1,'kookmin::cs::fouram::nurumikeyboard::inputmethod::NurumiIME']]],
  ['right_5fparentheses',['Right_parentheses',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_special_characters.html#aeb5033929c6bf52557b8bf91185d17f9',1,'kookmin::cs::fouram::nurumikeyboard::automata::SpecialCharacters']]],
  ['rightimg',['rightImg',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_motion_keyboard_view.html#ab2c3a1223b9e26623460be26d1719d6f',1,'kookmin::cs::fouram::nurumikeyboard::inputmethod::MotionKeyboardView']]],
  ['ring_5f_5ffinger',['RING__FINGER',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_motion_keyboard_view.html#a7b0971d87588cba92abee83ac980c6ff',1,'kookmin::cs::fouram::nurumikeyboard::inputmethod::MotionKeyboardView']]]
];
