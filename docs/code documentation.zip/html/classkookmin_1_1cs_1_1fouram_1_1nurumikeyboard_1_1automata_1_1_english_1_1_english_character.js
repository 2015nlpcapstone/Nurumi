var classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_english_1_1_english_character =
[
    [ "EnglishCharacter", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_english_1_1_english_character.html#a086ab3bd17047059588f48fdd5c3149f", null ],
    [ "getName", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_english_1_1_english_character.html#a8b6d6e0eec8d7e1c5ed17f3f2ba29b3f", null ],
    [ "getUnicode", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_english_1_1_english_character.html#a9cab861c87e6c91a839723a3050afd44", null ],
    [ "name", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_english_1_1_english_character.html#af221158d798f52c36ef0bd291587d609", null ],
    [ "unicode", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_english_1_1_english_character.html#a141c1ef1a6060e98e41320d29baf3034", null ]
];