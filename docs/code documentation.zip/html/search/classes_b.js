var searchData=
[
  ['vowel',['Vowel',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1korean_character_1_1_vowel.html',1,'kookmin::cs::fouram::nurumikeyboard::automata::koreanCharacter']]]
];
