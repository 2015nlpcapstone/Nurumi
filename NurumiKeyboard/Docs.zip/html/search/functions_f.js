var searchData=
[
  ['variable_5finitial',['variable_initial',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_korean_cheon_ji_in.html#a11db5957e4f3bc449b9ebc6d7ed4c839',1,'kookmin::cs::fouram::nurumikeyboard::automata::KoreanCheonJiIn']]]
];
