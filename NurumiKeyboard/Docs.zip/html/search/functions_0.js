var searchData=
[
  ['bok_5fjaeum',['BOK_JAEUM',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_i_m_e___automata_1_1_automata__type___kor__1.html#a5d1707e3e295b8b7c820b6c5de4582f6',1,'com::fouram::nurumikeyboard::IME_Automata::Automata_type_Kor_1']]],
  ['buffer_5fclean',['buffer_clean',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_i_m_e___automata_1_1_automata__type___kor__2.html#a3e86bafe789eb655eb5717003a7b177a',1,'com.fouram.nurumikeyboard.IME_Automata.Automata_type_Kor_2.buffer_clean()'],['../classcom_1_1fouram_1_1nurumikeyboard_1_1_i_m_e___automata_1_1_automata__type___kor__3.html#a9a70f0e2ef1d829ad7e65cd0db011d25',1,'com.fouram.nurumikeyboard.IME_Automata.Automata_type_Kor_3.buffer_clean()']]],
  ['buffer_5fclear',['buffer_clear',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_i_m_e___automata_1_1_automata__type___kor__1.html#a17777ccbda36443a18608fda56e888c1',1,'com::fouram::nurumikeyboard::IME_Automata::Automata_type_Kor_1']]]
];
