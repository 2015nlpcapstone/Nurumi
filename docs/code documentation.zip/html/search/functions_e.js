var searchData=
[
  ['vowel',['Vowel',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1korean_character_1_1_vowel.html#aaec3ec154ba30ca8894a3c41b74aa479',1,'kookmin::cs::fouram::nurumikeyboard::automata::koreanCharacter::Vowel']]]
];
