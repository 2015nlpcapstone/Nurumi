var searchData=
[
  ['nextjaeum',['nextjaeum',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_korean_cheon_ji_in.html#a377cae9a4311982c1a63e21edd782293',1,'kookmin::cs::fouram::nurumikeyboard::automata::KoreanCheonJiIn']]],
  ['numfingers',['numFingers',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_motion_keyboard_view.html#aeeb97e8770cf61b756da703e95a911ed',1,'kookmin.cs.fouram.nurumikeyboard.inputmethod.MotionKeyboardView.numFingers()'],['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_nurumi_i_m_e.html#a10e8973d8bd9331bfe6772cd9bc2b126',1,'kookmin.cs.fouram.nurumikeyboard.inputmethod.NurumiIME.numFingers()']]],
  ['nurumiime',['NurumiIME',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_nurumi_i_m_e.html',1,'kookmin::cs::fouram::nurumikeyboard::inputmethod']]],
  ['nurumiime_2ejava',['NurumiIME.java',['../_nurumi_i_m_e_8java.html',1,'']]]
];
