var searchData=
[
  ['replace_5fto',['replace_to',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_i_m_e___automata_1_1_automata__type___kor__2.html#a4d35e8ca3b6406543cfb22baf3671823',1,'com.fouram.nurumikeyboard.IME_Automata.Automata_type_Kor_2.replace_to()'],['../classcom_1_1fouram_1_1nurumikeyboard_1_1_i_m_e___automata_1_1_automata__type___kor__3.html#a9d9cfba0f2a4d62544d40e27a71a2dc0',1,'com.fouram.nurumikeyboard.IME_Automata.Automata_type_Kor_3.replace_to()']]],
  ['restartmng',['restartMng',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_nurumi_i_m_e.html#ad8d1edc821cae9d6c7a5473c271afdd8',1,'com::fouram::nurumikeyboard::NurumiIME::NurumiIME']]]
];
