var searchData=
[
  ['ibtninform',['ibtnInform',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_nurumi_i_m_e.html#a514aa82677804f288da51b27d2e83ed3',1,'kookmin::cs::fouram::nurumikeyboard::inputmethod::NurumiIME']]],
  ['ibtnsetting',['ibtnSetting',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_nurumi_i_m_e.html#ab2e1d3d336dde8beaed151684b7630a1',1,'kookmin::cs::fouram::nurumikeyboard::inputmethod::NurumiIME']]],
  ['ic',['ic',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_i_m_e___automata.html#ad4ffc0e9e14ac063bff9aa1fde6805e7',1,'kookmin::cs::fouram::nurumikeyboard::automata::IME_Automata']]],
  ['imageview',['imageView',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_information_activity.html#ad3b25d9a04bd1d22267f7ec234c564c4',1,'kookmin::cs::fouram::nurumikeyboard::inputmethod::InformationActivity']]],
  ['ime',['ime',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_motion_keyboard_view.html#a6e78d8267f31a7c2dd192b280a271357',1,'kookmin::cs::fouram::nurumikeyboard::inputmethod::MotionKeyboardView']]],
  ['index_5ffinger',['INDEX_FINGER',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_motion_keyboard_view.html#ac6d0679b923da53116bf30ca59eb1884',1,'kookmin::cs::fouram::nurumikeyboard::inputmethod::MotionKeyboardView']]],
  ['inner_5fcircle_5fsize',['INNER_CIRCLE_SIZE',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_motion_keyboard_view.html#a53877181f9f3ec6eb02cc060a4d107eb',1,'kookmin::cs::fouram::nurumikeyboard::inputmethod::MotionKeyboardView']]],
  ['innercirclesize',['innerCircleSize',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_motion_keyboard_view.html#a5f3fbc12a9ae9d88f2a4b28bf3b82676',1,'kookmin::cs::fouram::nurumikeyboard::inputmethod::MotionKeyboardView']]],
  ['inputchar',['inputChar',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_korean.html#a4194242f87e0f4daf50b6b6416acf114',1,'kookmin::cs::fouram::nurumikeyboard::automata::Korean']]],
  ['inputstartflag',['inputStartFlag',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_motion_keyboard_view.html#ad3b3aee0236507bdbd3897226429b411',1,'kookmin::cs::fouram::nurumikeyboard::inputmethod::MotionKeyboardView']]],
  ['invalid_5fcircle',['INVALID_CIRCLE',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_motion_keyboard_view.html#aad5c5c3608887ea7d041199d23f8fa7e',1,'kookmin::cs::fouram::nurumikeyboard::inputmethod::MotionKeyboardView']]]
];
