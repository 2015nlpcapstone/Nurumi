var searchData=
[
  ['text_5fto_5fcommit',['text_to_commit',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_i_m_e___automata_1_1_automata__type___kor__3.html#ae1925bbba05c6b62c0a85bbe380c6407',1,'com.fouram.nurumikeyboard.IME_Automata.Automata_type_Kor_3.text_to_commit()'],['../classcom_1_1fouram_1_1nurumikeyboard_1_1_i_m_e___automata_1_1_automata__type___kor__3.html#ae07bb475ff2484dc48b0afb4af5cbc12',1,'com.fouram.nurumikeyboard.IME_Automata.Automata_type_Kor_3.text_to_commit(String str)']]],
  ['thumb_5ffinger',['THUMB_FINGER',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_i_m_e___automata_1_1_i_m_e___automata.html#af5c22548330651718ad1de20bc0f8875',1,'com::fouram::nurumikeyboard::IME_Automata::IME_Automata']]]
];
