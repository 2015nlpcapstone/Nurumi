var searchData=
[
  ['initialize',['initialize',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_m_keyboard_view.html#a536f8d1527df8c5013dc66d253ac5dae',1,'com::fouram::nurumikeyboard::NurumiIME::MKeyboardView']]],
  ['isfullscreenmode',['isFullscreenMode',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_nurumi_i_m_e.html#a7b278c1ebec576db4897dccc7b6b34da',1,'com::fouram::nurumikeyboard::NurumiIME::NurumiIME']]]
];
