var searchData=
[
  ['oe',['OE',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_korean.html#a73c0b82fdf2625804b231ae322f29fb8',1,'kookmin::cs::fouram::nurumikeyboard::automata::Korean']]],
  ['oh',['OH',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_korean.html#a919cc23542791bcf75daf2d1f4214b4e',1,'kookmin::cs::fouram::nurumikeyboard::automata::Korean']]],
  ['oldptarr',['oldPtArr',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_motion_keyboard_view.html#a511794501ddbaeee21e58a9c16041683',1,'kookmin::cs::fouram::nurumikeyboard::inputmethod::MotionKeyboardView']]],
  ['one',['One',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_special_characters.html#a8dc26a3b8e2e05f17cbae9ae2fc91421',1,'kookmin::cs::fouram::nurumikeyboard::automata::SpecialCharacters']]],
  ['onpreferencechangelistener',['onPreferenceChangeListener',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_setting_activity.html#adc752fbbd895f4a9e23e206722283f21',1,'kookmin::cs::fouram::nurumikeyboard::inputmethod::SettingActivity']]],
  ['ourinstance',['ourInstance',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_automata_state_context.html#a909981be8f41271ee1e8f4d3ddb3a0a8',1,'kookmin::cs::fouram::nurumikeyboard::automata::AutomataStateContext']]]
];
