var dir_b45a734663b97eead6929e5ae00c8ca9 =
[
    [ "English.java", "_english_8java.html", [
      [ "English", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_english.html", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_english" ]
    ] ],
    [ "IME_Automata.java", "_i_m_e___automata_8java.html", [
      [ "IME_Automata", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_i_m_e___automata.html", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_i_m_e___automata" ]
    ] ],
    [ "KoreanAdvancedNatartgul.java", "_korean_advanced_natartgul_8java.html", [
      [ "KoreanAdvancedNatartgul", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_korean_advanced_natartgul.html", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_korean_advanced_natartgul" ]
    ] ],
    [ "KoreanCheonJiIn.java", "_korean_cheon_ji_in_8java.html", [
      [ "KoreanCheonJiIn", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_korean_cheon_ji_in.html", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_korean_cheon_ji_in" ]
    ] ],
    [ "KoreanNaratgul.java", "_korean_naratgul_8java.html", [
      [ "KoreanNaratgul", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_korean_naratgul.html", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_korean_naratgul" ]
    ] ],
    [ "SpecialCharacters.java", "_special_characters_8java.html", [
      [ "SpecialCharacters", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_special_characters.html", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_special_characters" ]
    ] ]
];