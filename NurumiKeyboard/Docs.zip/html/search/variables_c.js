var searchData=
[
  ['oldptarr',['oldPtArr',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_motion_keyboard_view.html#a511794501ddbaeee21e58a9c16041683',1,'kookmin::cs::fouram::nurumikeyboard::inputmethod::MotionKeyboardView']]],
  ['onpreferencechangelistener',['onPreferenceChangeListener',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_setting_activity.html#adc752fbbd895f4a9e23e206722283f21',1,'kookmin::cs::fouram::nurumikeyboard::inputmethod::SettingActivity']]]
];
