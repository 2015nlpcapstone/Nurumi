var searchData=
[
  ['changekeyboardtype',['changeKeyboardType',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_nurumi_i_m_e.html#ae1cd964051bec689f9065da9825bbcb7',1,'kookmin::cs::fouram::nurumikeyboard::inputmethod::NurumiIME']]],
  ['checkdirection',['checkDirection',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_motion_keyboard_view.html#a02263a9dccc2c2bd248dc667396f6456',1,'kookmin::cs::fouram::nurumikeyboard::inputmethod::MotionKeyboardView']]],
  ['checktouchedcircle',['checkTouchedCircle',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_motion_keyboard_view.html#a9dc3381a2c4d392dd6280bd3219e2181',1,'kookmin::cs::fouram::nurumikeyboard::inputmethod::MotionKeyboardView']]],
  ['circledown',['circleDown',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_motion_keyboard_view.html#a21208f5084b2fb5204af13d884e406ec',1,'kookmin::cs::fouram::nurumikeyboard::inputmethod::MotionKeyboardView']]],
  ['clear_5fbuffer',['clear_buffer',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_automata_state_context.html#afcd4c3b0d3d149d2721f643825aeb066',1,'kookmin::cs::fouram::nurumikeyboard::automata::AutomataStateContext']]],
  ['clearlists',['clearLists',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_motion_keyboard_view.html#a23b25ed2590baaad4eaa70525b59fc17',1,'kookmin::cs::fouram::nurumikeyboard::inputmethod::MotionKeyboardView']]],
  ['consonant',['Consonant',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1korean_character_1_1_consonant.html#a670aba4879c03fdc26822fae50cf16e0',1,'kookmin::cs::fouram::nurumikeyboard::automata::koreanCharacter::Consonant']]]
];
