var searchData=
[
  ['vg',['vg',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_nurumi_i_m_e.html#addc58b240728adb839c40fa65e1b89bb',1,'com::fouram::nurumikeyboard::NurumiIME::NurumiIME']]]
];
