var searchData=
[
  ['text_5fto_5fcommit',['text_to_commit',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_i_m_e___automata.html#af5c32eea75be1bf8abcc1f9e95a3ec85',1,'kookmin::cs::fouram::nurumikeyboard::automata::IME_Automata']]],
  ['thumb_5ffinger',['THUMB_FINGER',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_i_m_e___automata.html#a7173be1a5f217d2777aae9e869e41b68',1,'kookmin::cs::fouram::nurumikeyboard::automata::IME_Automata']]]
];
