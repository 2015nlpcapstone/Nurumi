var searchData=
[
  ['ime_5fautomata',['IME_Automata',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_i_m_e___automata_1_1_i_m_e___automata.html',1,'com::fouram::nurumikeyboard::IME_Automata']]],
  ['informationactivity',['InformationActivity',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_information_activity.html',1,'com::fouram::nurumikeyboard::NurumiIME']]]
];
