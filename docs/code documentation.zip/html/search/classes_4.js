var searchData=
[
  ['ime_5fautomata',['IME_Automata',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_i_m_e___automata.html',1,'kookmin::cs::fouram::nurumikeyboard::automata']]],
  ['informationactivity',['InformationActivity',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_information_activity.html',1,'kookmin::cs::fouram::nurumikeyboard::inputmethod']]]
];
