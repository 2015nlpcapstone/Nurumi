var searchData=
[
  ['wisp_5fflare',['WISP_FLARE',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___kor__3.html#ac493a84a4d6faa6dd30e13e957ffdb7a',1,'com::fouram::nurumikeyboard::NurumiIME::Automata_type_Kor_3']]]
];
