var searchData=
[
  ['variable_5finitial',['variable_initial',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_korean_cheon_ji_in.html#a11db5957e4f3bc449b9ebc6d7ed4c839',1,'kookmin::cs::fouram::nurumikeyboard::automata::KoreanCheonJiIn']]],
  ['vg',['vg',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_nurumi_i_m_e.html#a3ccbb1afd4aa28ecd9fc51c56074626a',1,'kookmin::cs::fouram::nurumikeyboard::inputmethod::NurumiIME']]]
];
