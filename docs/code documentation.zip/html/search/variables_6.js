var searchData=
[
  ['giyeok',['GIYEOK',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_korean.html#a6a548f658aae25f78a72691c5a63cd94',1,'kookmin::cs::fouram::nurumikeyboard::automata::Korean']]],
  ['giyeok_5fsiot',['GIYEOK_SIOT',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_korean.html#aeca3baf6ca1338fd50954d3d3527dd39',1,'kookmin::cs::fouram::nurumikeyboard::automata::Korean']]]
];
