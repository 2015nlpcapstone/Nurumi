var dir_9d2c8f496b531e843f14c3a3a559f8dc =
[
    [ "Consonant.java", "_consonant_8java.html", [
      [ "Consonant", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1korean_character_1_1_consonant.html", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1korean_character_1_1_consonant" ]
    ] ],
    [ "KoreanCharacter.java", "_korean_character_8java.html", [
      [ "KoreanCharacter", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1korean_character_1_1_korean_character.html", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1korean_character_1_1_korean_character" ]
    ] ],
    [ "Vowel.java", "_vowel_8java.html", [
      [ "Vowel", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1korean_character_1_1_vowel.html", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1korean_character_1_1_vowel" ]
    ] ]
];