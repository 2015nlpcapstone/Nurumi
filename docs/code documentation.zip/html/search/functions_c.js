var searchData=
[
  ['restartmng',['restartMng',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_nurumi_i_m_e.html#a260f598785fc224c0d5b6db3df40d6d9',1,'kookmin::cs::fouram::nurumikeyboard::inputmethod::NurumiIME']]]
];
