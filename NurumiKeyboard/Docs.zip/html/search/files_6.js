var searchData=
[
  ['settingactivity_2ejava',['SettingActivity.java',['../_setting_activity_8java.html',1,'']]],
  ['specialcharacters_2ejava',['SpecialCharacters.java',['../_special_characters_8java.html',1,'']]]
];
