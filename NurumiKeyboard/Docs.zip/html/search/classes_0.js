var searchData=
[
  ['automata_5ftype_5feng',['Automata_type_Eng',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_i_m_e___automata_1_1_automata__type___eng.html',1,'com::fouram::nurumikeyboard::IME_Automata']]],
  ['automata_5ftype_5fkor_5f1',['Automata_type_Kor_1',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_i_m_e___automata_1_1_automata__type___kor__1.html',1,'com::fouram::nurumikeyboard::IME_Automata']]],
  ['automata_5ftype_5fkor_5f2',['Automata_type_Kor_2',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_i_m_e___automata_1_1_automata__type___kor__2.html',1,'com::fouram::nurumikeyboard::IME_Automata']]],
  ['automata_5ftype_5fkor_5f3',['Automata_type_Kor_3',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_i_m_e___automata_1_1_automata__type___kor__3.html',1,'com::fouram::nurumikeyboard::IME_Automata']]],
  ['automata_5ftype_5fspc',['Automata_type_Spc',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_i_m_e___automata_1_1_automata__type___spc.html',1,'com::fouram::nurumikeyboard::IME_Automata']]]
];
