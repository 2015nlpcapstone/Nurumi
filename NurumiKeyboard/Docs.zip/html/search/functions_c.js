var searchData=
[
  ['replace_5fto',['replace_to',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_korean_advanced_natartgul.html#afd12ef769bf71b428099affc1ae918a3',1,'kookmin.cs.fouram.nurumikeyboard.automata.KoreanAdvancedNatartgul.replace_to()'],['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_korean_naratgul.html#ab70d1e48f9bf1be1596c7dd19c93e247',1,'kookmin.cs.fouram.nurumikeyboard.automata.KoreanNaratgul.replace_to()']]],
  ['restartmng',['restartMng',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_nurumi_i_m_e.html#a260f598785fc224c0d5b6db3df40d6d9',1,'kookmin::cs::fouram::nurumikeyboard::inputmethod::NurumiIME']]]
];
