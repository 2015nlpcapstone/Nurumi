var classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_state_jongsung =
[
    [ "buildCharacter", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_state_jongsung.html#ad19bc3e33d86749f903879c4603c4529", null ]
];