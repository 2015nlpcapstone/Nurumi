var searchData=
[
  ['generate_5fkorean_5fchar_5fcode',['generate_korean_char_code',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___kor__1.html#a5bf90eafa1c6092ec869ae61ec6f7c75',1,'com.fouram.nurumikeyboard.NurumiIME.Automata_type_Kor_1.generate_korean_char_code()'],['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___kor__3.html#a66e96d8dc1ec810c9755079a93d2ea63',1,'com.fouram.nurumikeyboard.NurumiIME.Automata_type_Kor_3.generate_korean_char_code()']]]
];
