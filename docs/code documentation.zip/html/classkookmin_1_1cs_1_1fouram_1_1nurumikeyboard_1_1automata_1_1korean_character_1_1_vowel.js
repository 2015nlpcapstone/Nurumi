var classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1korean_character_1_1_vowel =
[
    [ "Vowel", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1korean_character_1_1_vowel.html#aaec3ec154ba30ca8894a3c41b74aa479", null ],
    [ "getCharNum", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1korean_character_1_1_vowel.html#a5d2c47d6bf823e6f4a3f8d2fa7edce2d", null ],
    [ "getName", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1korean_character_1_1_vowel.html#a05d2b46378ef8478f257c5dd87c51963", null ],
    [ "getUnicode", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1korean_character_1_1_vowel.html#a7d774b59b756bacf168cd86c8db8d46e", null ],
    [ "setUnicode", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1korean_character_1_1_vowel.html#abe85bcdeb700f5cfeb7ae5f35b2cfb56", null ],
    [ "charNum", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1korean_character_1_1_vowel.html#a2ef4bc8769d14113e924590558dacb52", null ]
];