var searchData=
[
  ['generate_5fkorean_5fchar_5fcode',['generate_korean_char_code',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_korean_advanced_natartgul.html#af00bdf4768d6bb5fa13821ce7af34f85',1,'kookmin.cs.fouram.nurumikeyboard.automata.KoreanAdvancedNatartgul.generate_korean_char_code()'],['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_korean_cheon_ji_in.html#a51cd978b61ed3bdbf9e5f432e41c1255',1,'kookmin.cs.fouram.nurumikeyboard.automata.KoreanCheonJiIn.generate_korean_char_code()'],['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_korean_naratgul.html#a9b92a92c4de0365486a6a6be7fcd699c',1,'kookmin.cs.fouram.nurumikeyboard.automata.KoreanNaratgul.generate_korean_char_code()']]]
];
