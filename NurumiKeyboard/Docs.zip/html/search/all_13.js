var searchData=
[
  ['variable_5finitial',['variable_initial',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_i_m_e___automata_1_1_automata__type___kor__1.html#abf276165bb7af24ac8c3990a01492f02',1,'com::fouram::nurumikeyboard::IME_Automata::Automata_type_Kor_1']]],
  ['vg',['vg',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_nurumi_i_m_e.html#addc58b240728adb839c40fa65e1b89bb',1,'com::fouram::nurumikeyboard::NurumiIME::NurumiIME']]]
];
