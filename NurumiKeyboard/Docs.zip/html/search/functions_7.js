var searchData=
[
  ['jong_5fseong_5fjaeum',['JONG_SEONG_JAEUM',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_korean_cheon_ji_in.html#ae2c44fed2891dacac321a031261db419',1,'kookmin::cs::fouram::nurumikeyboard::automata::KoreanCheonJiIn']]],
  ['jung_5fseong_5fmoeum',['JUNG_SEONG_MOEUM',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_korean_cheon_ji_in.html#a39d4b4de179f65d0bc9ca6b5c60a05b4',1,'kookmin::cs::fouram::nurumikeyboard::automata::KoreanCheonJiIn']]]
];
