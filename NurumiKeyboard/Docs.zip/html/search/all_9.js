var searchData=
[
  ['keyboardtypeflag',['keyboardTypeFlag',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_nurumi_i_m_e.html#a75869df0c1f3fddbf46b08000511042a',1,'com::fouram::nurumikeyboard::NurumiIME::NurumiIME']]],
  ['kor',['KOR',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_nurumi_i_m_e.html#a2c8652d0f241a17e70cf7980f9b70a00',1,'com::fouram::nurumikeyboard::NurumiIME::NurumiIME']]]
];
