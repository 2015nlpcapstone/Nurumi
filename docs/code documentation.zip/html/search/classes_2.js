var searchData=
[
  ['circlelinkedwithptid',['CircleLinkedWithPtId',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_motion_keyboard_view_1_1_circle_linked_with_pt_id.html',1,'kookmin::cs::fouram::nurumikeyboard::inputmethod::MotionKeyboardView']]],
  ['consonant',['Consonant',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1korean_character_1_1_consonant.html',1,'kookmin::cs::fouram::nurumikeyboard::automata::koreanCharacter']]]
];
