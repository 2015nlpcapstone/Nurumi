var searchData=
[
  ['onmkeyboardgesturelistener',['OnMKeyboardGestureListener',['../interfacecom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_on_m_keyboard_gesture_listener.html',1,'com::fouram::nurumikeyboard::NurumiIME']]]
];
