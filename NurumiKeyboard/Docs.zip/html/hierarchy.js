var hierarchy =
[
    [ "com.fouram.nurumikeyboard.NurumiIME.MKeyboardView.CircleLinkedWithPtId", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_m_keyboard_view_1_1_circle_linked_with_pt_id.html", null ],
    [ "com.fouram.nurumikeyboard.NurumiIME.IME_Automata", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_i_m_e___automata.html", [
      [ "com.fouram.nurumikeyboard.NurumiIME.Automata_type_Eng", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___eng.html", null ],
      [ "com.fouram.nurumikeyboard.NurumiIME.Automata_type_Kor_1", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___kor__1.html", null ],
      [ "com.fouram.nurumikeyboard.NurumiIME.Automata_type_Kor_2", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___kor__2.html", null ],
      [ "com.fouram.nurumikeyboard.NurumiIME.Automata_type_Kor_3", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___kor__3.html", null ],
      [ "com.fouram.nurumikeyboard.NurumiIME.Automata_type_Spc", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___spc.html", null ]
    ] ],
    [ "com.fouram.nurumikeyboard.NurumiIME.OnMKeyboardGestureListener", "interfacecom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_on_m_keyboard_gesture_listener.html", [
      [ "com.fouram.nurumikeyboard.NurumiIME.NurumiIME", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_nurumi_i_m_e.html", null ]
    ] ],
    [ "com.fouram.nurumikeyboard.NurumiIME.MKeyboardView.PtIdLinkedWithPtIndex", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_m_keyboard_view_1_1_pt_id_linked_with_pt_index.html", null ],
    [ "Activity", null, [
      [ "com.fouram.nurumikeyboard.NurumiIME.InformationActivity", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_information_activity.html", null ]
    ] ],
    [ "InputMethodService", null, [
      [ "com.fouram.nurumikeyboard.NurumiIME.NurumiIME", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_nurumi_i_m_e.html", null ]
    ] ],
    [ "PreferenceActivity", null, [
      [ "com.fouram.nurumikeyboard.NurumiIME.SettingActivity", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_setting_activity.html", null ]
    ] ],
    [ "View", null, [
      [ "com.fouram.nurumikeyboard.NurumiIME.MKeyboardView", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_m_keyboard_view.html", null ]
    ] ]
];