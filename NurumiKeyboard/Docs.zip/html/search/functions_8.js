var searchData=
[
  ['mkeyboardview',['MKeyboardView',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_m_keyboard_view.html#a970fc12bcbc4830bea85945fd4909edd',1,'com.fouram.nurumikeyboard.NurumiIME.MKeyboardView.MKeyboardView(Context context, AttributeSet attrs)'],['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_m_keyboard_view.html#a565bb11cbc920cca01f533beb7468419',1,'com.fouram.nurumikeyboard.NurumiIME.MKeyboardView.MKeyboardView(Context context)']]],
  ['mode_5fenglish',['MODE_ENGLISH',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___eng.html#a9745c8e22e87e80f9171241141a63263',1,'com::fouram::nurumikeyboard::NurumiIME::Automata_type_Eng']]],
  ['moeumbuffer_5fclear',['Moeumbuffer_clear',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___kor__1.html#af57f325dcbff162153adb23d1b0cbc38',1,'com::fouram::nurumikeyboard::NurumiIME::Automata_type_Kor_1']]],
  ['motioncheck',['motionCheck',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_m_keyboard_view.html#a657f24f9888d141266179c6dc971103f',1,'com::fouram::nurumikeyboard::NurumiIME::MKeyboardView']]]
];
