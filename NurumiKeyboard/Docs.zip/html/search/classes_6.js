var searchData=
[
  ['onmkeyboardgesturelistener',['OnMKeyboardGestureListener',['../interfacekookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_on_m_keyboard_gesture_listener.html',1,'kookmin::cs::fouram::nurumikeyboard::inputmethod']]]
];
