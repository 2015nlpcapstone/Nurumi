var searchData=
[
  ['pinky_5ffinger',['PINKY_FINGER',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_i_m_e___automata.html#ae74bf29b24b8d9ed768c2eca51080477',1,'kookmin::cs::fouram::nurumikeyboard::automata::IME_Automata']]],
  ['plp',['plp',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_motion_keyboard_view.html#a439ad44affb6bf806e1b35dc43d77f5f',1,'kookmin::cs::fouram::nurumikeyboard::inputmethod::MotionKeyboardView']]],
  ['pnt',['pnt',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_motion_keyboard_view.html#adcb366394280a2eab18f33cd70ca396e',1,'kookmin::cs::fouram::nurumikeyboard::inputmethod::MotionKeyboardView']]],
  ['pref_5fcho',['PREF_CHO',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_i_m_e___automata.html#abe2f2964dded557753fd063544b9eef1',1,'kookmin::cs::fouram::nurumikeyboard::automata::IME_Automata']]],
  ['pref_5fenglish_5fb',['PREF_ENGLISH_B',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_english.html#aaa864efc671376d326ab807a6a88b26b',1,'kookmin::cs::fouram::nurumikeyboard::automata::English']]],
  ['pref_5fenglish_5fs',['PREF_ENGLISH_S',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_english.html#ad0370bdb57dbe1bb4f64f89b475652a4',1,'kookmin::cs::fouram::nurumikeyboard::automata::English']]],
  ['pref_5fjong',['PREF_JONG',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_i_m_e___automata.html#a41bbb487255623af28807b8cc86f4c19',1,'kookmin::cs::fouram::nurumikeyboard::automata::IME_Automata']]],
  ['pref_5fjung',['PREF_JUNG',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_i_m_e___automata.html#aa581d2b982244194ce90c265ef51cebb',1,'kookmin::cs::fouram::nurumikeyboard::automata::IME_Automata']]],
  ['ptarr',['ptArr',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_motion_keyboard_view.html#afa8412fc6e6b4c87be2cae45b4653dea',1,'kookmin::cs::fouram::nurumikeyboard::inputmethod::MotionKeyboardView']]]
];
