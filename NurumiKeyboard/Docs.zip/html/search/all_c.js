var searchData=
[
  ['nextjaeum',['nextjaeum',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_i_m_e___automata_1_1_automata__type___kor__1.html#a2c2f5360e349e67bb31e32ec2241e4e9',1,'com::fouram::nurumikeyboard::IME_Automata::Automata_type_Kor_1']]],
  ['numfingers',['numFingers',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_m_keyboard_view.html#af2f59861ed61c6357020e1350be33a5a',1,'com.fouram.nurumikeyboard.NurumiIME.MKeyboardView.numFingers()'],['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_nurumi_i_m_e.html#a8da73863a9fc74d17aa828c3d6d7bf6b',1,'com.fouram.nurumikeyboard.NurumiIME.NurumiIME.numFingers()']]],
  ['nurumiime',['NurumiIME',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_nurumi_i_m_e.html',1,'com::fouram::nurumikeyboard::NurumiIME']]],
  ['nurumiime_2ejava',['NurumiIME.java',['../_nurumi_i_m_e_8java.html',1,'']]]
];
