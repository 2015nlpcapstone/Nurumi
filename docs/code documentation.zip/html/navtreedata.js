var NAVTREE =
[
  [ "NurumiKeyboard", "index.html", [
    [ "Packages", null, [
      [ "Packages", "namespaces.html", "namespaces" ]
    ] ],
    [ "Classes", null, [
      [ "Class List", "annotated.html", "annotated" ],
      [ "Class Index", "classes.html", null ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Functions", "functions_func.html", null ],
        [ "Variables", "functions_vars.html", "functions_vars" ]
      ] ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"_automata_state_context_8java.html",
"classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_korean_advanced_naratgul.html#ac8716c0a9efda80cba27a8be0ce8d934",
"classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_motion_keyboard_view.html#a334e0f9ba922c81945b57b5fb8a21d9e"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';