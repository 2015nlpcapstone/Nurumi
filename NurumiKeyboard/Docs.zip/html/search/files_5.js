var searchData=
[
  ['settingactivity_2ejava',['SettingActivity.java',['../_setting_activity_8java.html',1,'']]]
];
