var classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_setting_activity =
[
    [ "onCreate", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_setting_activity.html#a29d4ba6fad105a6d99e31e8c1443ad1d", null ],
    [ "onDestroy", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_setting_activity.html#ad5851965aa58fdcf4d3a0f1b32c2d04e", null ],
    [ "setOnPreferenceChange", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_setting_activity.html#af9d95ffc4d0c78e04d63488a891175dc", null ],
    [ "onPreferenceChangeListener", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_setting_activity.html#a5abedf272e17e5b765387358e1f89527", null ]
];