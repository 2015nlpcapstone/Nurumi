var classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___eng =
[
    [ "execute", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___eng.html#a42256e7f81db0e0b8ebde7d6d9e8d3ae", null ],
    [ "MODE_ENGLISH", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___eng.html#a9745c8e22e87e80f9171241141a63263", null ],
    [ "count_finger", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___eng.html#aad9ea39904519b14d584a8e5334b6cbb", null ],
    [ "DIRECTION_DOT", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___eng.html#afe4915f4ff6aca4a63d71e72b81c2044", null ],
    [ "DIRECTION_DOWN", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___eng.html#ab24b5cf12ef6b2b904e99135975b3720", null ],
    [ "DIRECTION_EMPTY", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___eng.html#a454d8fffcee924bfc4629dea3ceeb13a", null ],
    [ "DIRECTION_LEFT", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___eng.html#a5a3e55c89192332a7647c1f00f6ee71f", null ],
    [ "DIRECTION_RIGHT", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___eng.html#abe590899fc564c681b5c2494437dfdbb", null ],
    [ "DIRECTION_UP", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___eng.html#a5fe3a9d106460bd703335ca9937ff818", null ],
    [ "finger", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___eng.html#a6f3f8a31dd6325b9493718c9ef9ab013", null ],
    [ "ic", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___eng.html#aacb2649f7726e6a83d2b7468bb938fac", null ],
    [ "INDEX_FINGER", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___eng.html#a1183d9c871091a9425c1969587e5191f", null ],
    [ "MIDLE_FINGER", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___eng.html#a6e254b258d54134f19bb518cb2c86cc6", null ],
    [ "PINKY_FINGER", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___eng.html#ac1e67e14676b6ac2c9ab438090fb8e9d", null ],
    [ "PREF_ENGLISH_B", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___eng.html#ae1485b00334d2bf43b42386086f7f302", null ],
    [ "PREF_ENGLISH_S", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___eng.html#a244c74fa50bd71e5da373930dba0960d", null ],
    [ "RING__FINGER", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___eng.html#aca5a09d52c4e53fa484fc8c583c1d041", null ],
    [ "str_to_write", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___eng.html#a850a9a7cd8fc4d17f9226bba8d7a4b5d", null ],
    [ "THUMB_FINGER", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___eng.html#aec17525ff88317c267e84dd9b6ddde43", null ]
];