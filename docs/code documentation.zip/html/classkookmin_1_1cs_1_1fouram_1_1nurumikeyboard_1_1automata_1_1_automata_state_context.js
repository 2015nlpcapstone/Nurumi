var classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_automata_state_context =
[
    [ "AutomataStateContext", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_automata_state_context.html#add588532a78db35975e8eb5dd68222e3", null ],
    [ "buildCharacter", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_automata_state_context.html#ad21ecede926be3201f0f877eb99c2563", null ],
    [ "clear_buffer", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_automata_state_context.html#afcd4c3b0d3d149d2721f643825aeb066", null ],
    [ "getInstance", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_automata_state_context.html#a37ddc2905b6bde613720572bdd0a60ba", null ],
    [ "getKorean", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_automata_state_context.html#a14387b815c41d7e5403e68095f9acf32", null ],
    [ "setKorean", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_automata_state_context.html#a7bd8d456cae7c6c8502e0e442ba16741", null ],
    [ "setState", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_automata_state_context.html#ac8464eccbe2e0d8b3cc6fc23fe61d71f", null ],
    [ "buffer", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_automata_state_context.html#ab3458ab638b9bcb367b6de5f38fd409d", null ],
    [ "korean", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_automata_state_context.html#a1674b31cc712ad0b3233eb2e0ef280b5", null ],
    [ "ourInstance", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_automata_state_context.html#a909981be8f41271ee1e8f4d3ddb3a0a8", null ],
    [ "state", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_automata_state_context.html#a8f8e6c6c2e14a46048819fa0d9fa97da", null ]
];