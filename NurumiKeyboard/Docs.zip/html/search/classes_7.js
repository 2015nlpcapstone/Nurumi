var searchData=
[
  ['settingactivity',['SettingActivity',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_setting_activity.html',1,'com::fouram::nurumikeyboard::NurumiIME']]]
];
