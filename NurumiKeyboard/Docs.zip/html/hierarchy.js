var hierarchy =
[
    [ "kookmin.cs.fouram.nurumikeyboard.inputmethod.MotionKeyboardView.CircleLinkedWithPtId", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_motion_keyboard_view_1_1_circle_linked_with_pt_id.html", null ],
    [ "kookmin.cs.fouram.nurumikeyboard.automata.IME_Automata", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_i_m_e___automata.html", [
      [ "kookmin.cs.fouram.nurumikeyboard.automata.English", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_english.html", null ],
      [ "kookmin.cs.fouram.nurumikeyboard.automata.KoreanAdvancedNatartgul", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_korean_advanced_natartgul.html", null ],
      [ "kookmin.cs.fouram.nurumikeyboard.automata.KoreanCheonJiIn", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_korean_cheon_ji_in.html", null ],
      [ "kookmin.cs.fouram.nurumikeyboard.automata.KoreanNaratgul", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_korean_naratgul.html", null ],
      [ "kookmin.cs.fouram.nurumikeyboard.automata.SpecialCharacters", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_special_characters.html", null ]
    ] ],
    [ "kookmin.cs.fouram.nurumikeyboard.inputmethod.OnMKeyboardGestureListener", "interfacekookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_on_m_keyboard_gesture_listener.html", [
      [ "kookmin.cs.fouram.nurumikeyboard.inputmethod.NurumiIME", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_nurumi_i_m_e.html", null ]
    ] ],
    [ "kookmin.cs.fouram.nurumikeyboard.inputmethod.MotionKeyboardView.PtIdLinkedWithPtIndex", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_motion_keyboard_view_1_1_pt_id_linked_with_pt_index.html", null ],
    [ "Activity", null, [
      [ "kookmin.cs.fouram.nurumikeyboard.inputmethod.InformationActivity", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_information_activity.html", null ]
    ] ],
    [ "InputMethodService", null, [
      [ "kookmin.cs.fouram.nurumikeyboard.inputmethod.NurumiIME", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_nurumi_i_m_e.html", null ]
    ] ],
    [ "PreferenceActivity", null, [
      [ "kookmin.cs.fouram.nurumikeyboard.inputmethod.SettingActivity", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_setting_activity.html", null ]
    ] ],
    [ "View", null, [
      [ "kookmin.cs.fouram.nurumikeyboard.inputmethod.MotionKeyboardView", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_motion_keyboard_view.html", null ]
    ] ]
];