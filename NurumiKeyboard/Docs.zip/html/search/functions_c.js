var searchData=
[
  ['setautomata',['setAutomata',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_nurumi_i_m_e.html#ad88e325dd5770d892906b61b9858101c',1,'com::fouram::nurumikeyboard::NurumiIME::NurumiIME']]],
  ['setbitmap',['setBitmap',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_m_keyboard_view.html#a3cd3bbdbd5a6e655e134cbddc6090cfb',1,'com::fouram::nurumikeyboard::NurumiIME::MKeyboardView']]],
  ['setdpvalues',['setDpValues',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_m_keyboard_view.html#a0ed95284476289e2396331eb22dc45ec',1,'com::fouram::nurumikeyboard::NurumiIME::MKeyboardView']]],
  ['setextractviewshown',['setExtractViewShown',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_nurumi_i_m_e.html#ab2bcb5ce607676ca73f5a64b6b087973',1,'com::fouram::nurumikeyboard::NurumiIME::NurumiIME']]],
  ['setime',['setIme',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_m_keyboard_view.html#a879697fa9b15b251c012e1a6e688acd7',1,'com::fouram::nurumikeyboard::NurumiIME::MKeyboardView']]],
  ['setinformimage',['setInformImage',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_information_activity.html#a38f3f25000e0d7633316434162608d94',1,'com::fouram::nurumikeyboard::NurumiIME::InformationActivity']]],
  ['setonpreferencechange',['setOnPreferenceChange',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_setting_activity.html#af9d95ffc4d0c78e04d63488a891175dc',1,'com::fouram::nurumikeyboard::NurumiIME::SettingActivity']]],
  ['setstate',['setState',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_nurumi_i_m_e.html#a9b12e8a554fa0c51f6983990af717d1e',1,'com::fouram::nurumikeyboard::NurumiIME::NurumiIME']]],
  ['setviewid',['setViewId',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_nurumi_i_m_e.html#ae990520ed29bed11e3f6113163650849',1,'com::fouram::nurumikeyboard::NurumiIME::NurumiIME']]],
  ['startmultitouch',['startMultiTouch',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_m_keyboard_view.html#a2e05b77b14ceb804926bc33e9e3e88fa',1,'com::fouram::nurumikeyboard::NurumiIME::MKeyboardView']]]
];
