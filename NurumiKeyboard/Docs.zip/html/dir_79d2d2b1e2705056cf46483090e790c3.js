var dir_79d2d2b1e2705056cf46483090e790c3 =
[
    [ "InformationActivity.java", "_information_activity_8java.html", [
      [ "InformationActivity", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_information_activity.html", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_information_activity" ]
    ] ],
    [ "MotionKeyboardView.java", "_motion_keyboard_view_8java.html", [
      [ "MotionKeyboardView", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_motion_keyboard_view.html", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_motion_keyboard_view" ],
      [ "CircleLinkedWithPtId", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_motion_keyboard_view_1_1_circle_linked_with_pt_id.html", null ],
      [ "PtIdLinkedWithPtIndex", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_motion_keyboard_view_1_1_pt_id_linked_with_pt_index.html", null ]
    ] ],
    [ "NurumiIME.java", "_nurumi_i_m_e_8java.html", [
      [ "NurumiIME", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_nurumi_i_m_e.html", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_nurumi_i_m_e" ]
    ] ],
    [ "OnMKeyboardGestureListener.java", "_on_m_keyboard_gesture_listener_8java.html", [
      [ "OnMKeyboardGestureListener", "interfacekookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_on_m_keyboard_gesture_listener.html", "interfacekookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_on_m_keyboard_gesture_listener" ]
    ] ],
    [ "SettingActivity.java", "_setting_activity_8java.html", [
      [ "SettingActivity", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_setting_activity.html", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_setting_activity" ]
    ] ]
];