var namespacecom_1_1fouram_1_1nurumikeyboard =
[
    [ "IME_Automata", "namespacecom_1_1fouram_1_1nurumikeyboard_1_1_i_m_e___automata.html", "namespacecom_1_1fouram_1_1nurumikeyboard_1_1_i_m_e___automata" ],
    [ "NurumiIME", "namespacecom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e.html", "namespacecom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e" ]
];