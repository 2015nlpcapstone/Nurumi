var searchData=
[
  ['english',['English',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_english.html',1,'kookmin::cs::fouram::nurumikeyboard::automata']]],
  ['englishcharacter',['EnglishCharacter',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_english_1_1_english_character.html',1,'kookmin::cs::fouram::nurumikeyboard::automata::English']]]
];
