var searchData=
[
  ['ready_5fto_5fcommit_5ftext',['ready_to_commit_text',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_korean_advanced_natartgul.html#a23175f2e2f51a55c25df7d03a6484b65',1,'kookmin.cs.fouram.nurumikeyboard.automata.KoreanAdvancedNatartgul.ready_to_commit_text()'],['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_korean_naratgul.html#a0dc5eeb480619d0826b259da2adc14b4',1,'kookmin.cs.fouram.nurumikeyboard.automata.KoreanNaratgul.ready_to_commit_text()']]],
  ['restart',['restart',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_nurumi_i_m_e.html#a7f70e8d5f0568ea732b5d43d59289a69',1,'kookmin::cs::fouram::nurumikeyboard::inputmethod::NurumiIME']]],
  ['rightimg',['rightImg',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_motion_keyboard_view.html#ab2c3a1223b9e26623460be26d1719d6f',1,'kookmin::cs::fouram::nurumikeyboard::inputmethod::MotionKeyboardView']]],
  ['ring_5f_5ffinger',['RING__FINGER',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_i_m_e___automata.html#a56acb6924e390e335edda101c78b33db',1,'kookmin::cs::fouram::nurumikeyboard::automata::IME_Automata']]]
];
