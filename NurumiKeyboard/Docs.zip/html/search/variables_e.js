var searchData=
[
  ['ready_5fto_5fcommit_5ftext',['ready_to_commit_text',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___kor__3.html#ae68efa67d318b777b5365bf19b0aa375',1,'com::fouram::nurumikeyboard::NurumiIME::Automata_type_Kor_3']]],
  ['rightimg',['rightImg',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_m_keyboard_view.html#ae1f82cc38d6394ee0eb1db7c36ac1cbb',1,'com::fouram::nurumikeyboard::NurumiIME::MKeyboardView']]],
  ['ring_5f_5ffinger',['RING__FINGER',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___eng.html#aca5a09d52c4e53fa484fc8c583c1d041',1,'com.fouram.nurumikeyboard.NurumiIME.Automata_type_Eng.RING__FINGER()'],['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___kor__1.html#a7c9320f102adef9df1181bd0fe400e18',1,'com.fouram.nurumikeyboard.NurumiIME.Automata_type_Kor_1.RING__FINGER()'],['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___kor__3.html#a378e1007e152b85169f8c36bee242aaa',1,'com.fouram.nurumikeyboard.NurumiIME.Automata_type_Kor_3.RING__FINGER()']]],
  ['ring_5ffinger',['RING_FINGER',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___kor__2.html#a0f6c0d36b410c823fd9fc591d6c526a9',1,'com::fouram::nurumikeyboard::NurumiIME::Automata_type_Kor_2']]]
];
