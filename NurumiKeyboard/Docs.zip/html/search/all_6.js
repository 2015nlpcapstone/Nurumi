var searchData=
[
  ['generate_5fkorean_5fchar_5fcode',['generate_korean_char_code',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_i_m_e___automata_1_1_automata__type___kor__1.html#a234cab6ebdbf9f7bca9b5c4d42392aea',1,'com.fouram.nurumikeyboard.IME_Automata.Automata_type_Kor_1.generate_korean_char_code()'],['../classcom_1_1fouram_1_1nurumikeyboard_1_1_i_m_e___automata_1_1_automata__type___kor__3.html#a49c20d7e62c0e460dcb6206cdb248af1',1,'com.fouram.nurumikeyboard.IME_Automata.Automata_type_Kor_3.generate_korean_char_code()']]]
];
