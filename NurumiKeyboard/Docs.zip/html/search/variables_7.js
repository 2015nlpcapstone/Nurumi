var searchData=
[
  ['jong_5fseong',['JONG_SEONG',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_i_m_e___automata_1_1_automata__type___kor__1.html#a7feb2196ad97cc72dac428bf436f565d',1,'com.fouram.nurumikeyboard.IME_Automata.Automata_type_Kor_1.JONG_SEONG()'],['../classcom_1_1fouram_1_1nurumikeyboard_1_1_i_m_e___automata_1_1_automata__type___kor__3.html#a4c2b35498a33229364b1073882614140',1,'com.fouram.nurumikeyboard.IME_Automata.Automata_type_Kor_3.JONG_SEONG()']]],
  ['jung_5fseong',['JUNG_SEONG',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_i_m_e___automata_1_1_automata__type___kor__1.html#a4232519bfe39d4f94db2dc6f50c94a5c',1,'com.fouram.nurumikeyboard.IME_Automata.Automata_type_Kor_1.JUNG_SEONG()'],['../classcom_1_1fouram_1_1nurumikeyboard_1_1_i_m_e___automata_1_1_automata__type___kor__3.html#adbaf05cd4c54f778ed4789acda0a803e',1,'com.fouram.nurumikeyboard.IME_Automata.Automata_type_Kor_3.JUNG_SEONG()']]]
];
