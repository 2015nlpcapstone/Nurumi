var classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_special_characters_1_1_special_character =
[
    [ "SpecialCharacter", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_special_characters_1_1_special_character.html#a8b8918e448d10ee533a3230ed7d7beba", null ],
    [ "getName", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_special_characters_1_1_special_character.html#a488b2da9b9601db5ce379fec75c24460", null ],
    [ "getUnicode", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_special_characters_1_1_special_character.html#a1ad97c8a2abde3d6764680f69af19599", null ],
    [ "name", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_special_characters_1_1_special_character.html#ae01f3d418636c34101aa59a1a138a368", null ],
    [ "unicode", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_special_characters_1_1_special_character.html#a16a5ea3a492bcb0fdc4b056833acb826", null ]
];