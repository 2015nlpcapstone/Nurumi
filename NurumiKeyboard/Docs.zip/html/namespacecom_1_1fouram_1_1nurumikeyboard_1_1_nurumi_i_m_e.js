var namespacecom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e =
[
    [ "InformationActivity", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_information_activity.html", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_information_activity" ],
    [ "MKeyboardView", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_m_keyboard_view.html", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_m_keyboard_view" ],
    [ "NurumiIME", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_nurumi_i_m_e.html", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_nurumi_i_m_e" ],
    [ "OnMKeyboardGestureListener", "interfacecom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_on_m_keyboard_gesture_listener.html", "interfacecom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_on_m_keyboard_gesture_listener" ],
    [ "SettingActivity", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_setting_activity.html", "classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_setting_activity" ]
];