var searchData=
[
  ['bok_5fjaeum',['BOK_JAEUM',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_korean_cheon_ji_in.html#a3112965e8979cafae2f8f6834fd8cca2',1,'kookmin::cs::fouram::nurumikeyboard::automata::KoreanCheonJiIn']]],
  ['buffer_5fclean',['buffer_clean',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_korean_advanced_natartgul.html#a8fcf468265c181e0e56f949f277e6a24',1,'kookmin.cs.fouram.nurumikeyboard.automata.KoreanAdvancedNatartgul.buffer_clean()'],['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_korean_naratgul.html#a624e41a9f8b4cdef30a718aa976a31dd',1,'kookmin.cs.fouram.nurumikeyboard.automata.KoreanNaratgul.buffer_clean()']]],
  ['buffer_5fclear',['buffer_clear',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_korean_cheon_ji_in.html#a177b5d4d960e9529c825405d0db5338f',1,'kookmin::cs::fouram::nurumikeyboard::automata::KoreanCheonJiIn']]]
];
