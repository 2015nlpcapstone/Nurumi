var searchData=
[
  ['upimg',['upImg',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_m_keyboard_view.html#a263545527e5a11e749e17799969771e7',1,'com::fouram::nurumikeyboard::NurumiIME::MKeyboardView']]]
];
