var searchData=
[
  ['jong_5fseong_5fjaeum',['JONG_SEONG_JAEUM',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___kor__1.html#a56e2bd8d9cf53e73aa17ea48aa37a1b2',1,'com::fouram::nurumikeyboard::NurumiIME::Automata_type_Kor_1']]],
  ['jung_5fseong_5fmoeum',['JUNG_SEONG_MOEUM',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___kor__1.html#aed0cb2c1603ac9cce47648b23482b870',1,'com::fouram::nurumikeyboard::NurumiIME::Automata_type_Kor_1']]]
];
