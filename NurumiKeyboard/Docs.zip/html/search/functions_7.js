var searchData=
[
  ['jong_5fseong_5fjaeum',['JONG_SEONG_JAEUM',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_i_m_e___automata_1_1_automata__type___kor__1.html#a05053ead2311c2d14c2481bd072a4911',1,'com::fouram::nurumikeyboard::IME_Automata::Automata_type_Kor_1']]],
  ['jung_5fseong_5fmoeum',['JUNG_SEONG_MOEUM',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_i_m_e___automata_1_1_automata__type___kor__1.html#aebce04d02df8b3dd624763bc18607320',1,'com::fouram::nurumikeyboard::IME_Automata::Automata_type_Kor_1']]]
];
