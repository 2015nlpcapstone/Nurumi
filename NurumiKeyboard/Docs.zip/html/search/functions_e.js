var searchData=
[
  ['variable_5finitial',['variable_initial',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___kor__1.html#a7f17d2172ff291eac3973393bac1faff',1,'com::fouram::nurumikeyboard::NurumiIME::Automata_type_Kor_1']]]
];
