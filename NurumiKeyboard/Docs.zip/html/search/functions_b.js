var searchData=
[
  ['recyclebitmap',['recycleBitmap',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_m_keyboard_view.html#ab83f53c002ebfb869a155306c0d2f6c0',1,'com::fouram::nurumikeyboard::NurumiIME::MKeyboardView']]],
  ['replace_5fto',['replace_to',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___kor__3.html#a75a0050872ffdfc730f38f612c38c0ff',1,'com::fouram::nurumikeyboard::NurumiIME::Automata_type_Kor_3']]]
];
