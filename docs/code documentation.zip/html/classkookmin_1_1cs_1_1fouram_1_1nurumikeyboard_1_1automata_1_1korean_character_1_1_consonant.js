var classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1korean_character_1_1_consonant =
[
    [ "Consonant", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1korean_character_1_1_consonant.html#a670aba4879c03fdc26822fae50cf16e0", null ],
    [ "getCharNum", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1korean_character_1_1_consonant.html#a860ddf02e676cf50e59885c68223b64c", null ],
    [ "getCharNumCho", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1korean_character_1_1_consonant.html#a305748b930c50f0d06c6e06f4cd2b52e", null ],
    [ "getCharNumJong", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1korean_character_1_1_consonant.html#a6976ccf57ab9c108c41008de61b9abe3", null ],
    [ "getName", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1korean_character_1_1_consonant.html#a05d2b46378ef8478f257c5dd87c51963", null ],
    [ "getUnicode", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1korean_character_1_1_consonant.html#a7d774b59b756bacf168cd86c8db8d46e", null ],
    [ "setUnicode", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1korean_character_1_1_consonant.html#abe85bcdeb700f5cfeb7ae5f35b2cfb56", null ],
    [ "charNumCho", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1korean_character_1_1_consonant.html#a68a0c29cd5f31ae59592808e0f820e7d", null ],
    [ "charNumJong", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1korean_character_1_1_consonant.html#a2c2a14b4ecc4aa2f5e79415d0cf23b30", null ]
];