var searchData=
[
  ['oldptarr',['oldPtArr',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_m_keyboard_view.html#ac7da84e25f4d6414da9023da4a8d3ffa',1,'com::fouram::nurumikeyboard::NurumiIME::MKeyboardView']]],
  ['onpreferencechangelistener',['onPreferenceChangeListener',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_setting_activity.html#a5abedf272e17e5b765387358e1f89527',1,'com::fouram::nurumikeyboard::NurumiIME::SettingActivity']]]
];
