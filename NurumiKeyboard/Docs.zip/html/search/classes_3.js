var searchData=
[
  ['mkeyboardview',['MKeyboardView',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_m_keyboard_view.html',1,'com::fouram::nurumikeyboard::NurumiIME']]]
];
