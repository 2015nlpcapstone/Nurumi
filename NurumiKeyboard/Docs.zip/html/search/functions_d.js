var searchData=
[
  ['text_5fto_5fcommit',['text_to_commit',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___kor__3.html#afeb6a0102b38c62766b89542014455de',1,'com::fouram::nurumikeyboard::NurumiIME::Automata_type_Kor_3']]]
];
