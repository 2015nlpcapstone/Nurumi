var searchData=
[
  ['nextjaeum',['nextjaeum',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___kor__1.html#adc107f98cab2063556a9725200e34e22',1,'com::fouram::nurumikeyboard::NurumiIME::Automata_type_Kor_1']]],
  ['numfingers',['numFingers',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_m_keyboard_view.html#af2f59861ed61c6357020e1350be33a5a',1,'com.fouram.nurumikeyboard.NurumiIME.MKeyboardView.numFingers()'],['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_nurumi_i_m_e.html#a8da73863a9fc74d17aa828c3d6d7bf6b',1,'com.fouram.nurumikeyboard.NurumiIME.NurumiIME.numFingers()']]]
];
