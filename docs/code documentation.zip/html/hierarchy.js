var hierarchy =
[
    [ "kookmin.cs.fouram.nurumikeyboard.automata.AutomataStateContext", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_automata_state_context.html", null ],
    [ "kookmin.cs.fouram.nurumikeyboard.automata.BuildState", "interfacekookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_build_state.html", [
      [ "kookmin.cs.fouram.nurumikeyboard.automata.StateBokJongsung", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_state_bok_jongsung.html", null ],
      [ "kookmin.cs.fouram.nurumikeyboard.automata.StateChosung", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_state_chosung.html", null ],
      [ "kookmin.cs.fouram.nurumikeyboard.automata.StateJongsung", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_state_jongsung.html", null ],
      [ "kookmin.cs.fouram.nurumikeyboard.automata.StateJungsung", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_state_jungsung.html", [
        [ "kookmin.cs.fouram.nurumikeyboard.automata.StateBokJongThreeJaEum", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_state_bok_jong_three_ja_eum.html", null ],
        [ "kookmin.cs.fouram.nurumikeyboard.automata.StateJungThreeJaEum", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_state_jung_three_ja_eum.html", null ]
      ] ]
    ] ],
    [ "kookmin.cs.fouram.nurumikeyboard.inputmethod.MotionKeyboardView.CircleLinkedWithPtId", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_motion_keyboard_view_1_1_circle_linked_with_pt_id.html", null ],
    [ "kookmin.cs.fouram.nurumikeyboard.automata.English.EnglishCharacter", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_english_1_1_english_character.html", null ],
    [ "kookmin.cs.fouram.nurumikeyboard.automata.IME_Automata", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_i_m_e___automata.html", [
      [ "kookmin.cs.fouram.nurumikeyboard.automata.English", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_english.html", null ],
      [ "kookmin.cs.fouram.nurumikeyboard.automata.Korean", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_korean.html", [
        [ "kookmin.cs.fouram.nurumikeyboard.automata.KoreanAdvancedNaratgul", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_korean_advanced_naratgul.html", null ],
        [ "kookmin.cs.fouram.nurumikeyboard.automata.KoreanCheonJiIn", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_korean_cheon_ji_in.html", null ],
        [ "kookmin.cs.fouram.nurumikeyboard.automata.KoreanNaratgul", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_korean_naratgul.html", null ]
      ] ],
      [ "kookmin.cs.fouram.nurumikeyboard.automata.SpecialCharacters", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_special_characters.html", null ]
    ] ],
    [ "kookmin.cs.fouram.nurumikeyboard.automata.koreanCharacter.KoreanCharacter", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1korean_character_1_1_korean_character.html", [
      [ "kookmin.cs.fouram.nurumikeyboard.automata.koreanCharacter.Consonant", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1korean_character_1_1_consonant.html", null ],
      [ "kookmin.cs.fouram.nurumikeyboard.automata.koreanCharacter.Vowel", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1korean_character_1_1_vowel.html", null ]
    ] ],
    [ "kookmin.cs.fouram.nurumikeyboard.inputmethod.OnMKeyboardGestureListener", "interfacekookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_on_m_keyboard_gesture_listener.html", [
      [ "kookmin.cs.fouram.nurumikeyboard.inputmethod.NurumiIME", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_nurumi_i_m_e.html", null ]
    ] ],
    [ "kookmin.cs.fouram.nurumikeyboard.inputmethod.MotionKeyboardView.PtIdLinkedWithPtIndex", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_motion_keyboard_view_1_1_pt_id_linked_with_pt_index.html", null ],
    [ "kookmin.cs.fouram.nurumikeyboard.automata.SpecialCharacters.SpecialCharacter", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_special_characters_1_1_special_character.html", null ],
    [ "Activity", null, [
      [ "kookmin.cs.fouram.nurumikeyboard.inputmethod.InformationActivity", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_information_activity.html", null ]
    ] ],
    [ "InputMethodService", null, [
      [ "kookmin.cs.fouram.nurumikeyboard.inputmethod.NurumiIME", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_nurumi_i_m_e.html", null ]
    ] ],
    [ "PreferenceActivity", null, [
      [ "kookmin.cs.fouram.nurumikeyboard.inputmethod.SettingActivity", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_setting_activity.html", null ]
    ] ],
    [ "View", null, [
      [ "kookmin.cs.fouram.nurumikeyboard.inputmethod.MotionKeyboardView", "classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_motion_keyboard_view.html", null ]
    ] ]
];