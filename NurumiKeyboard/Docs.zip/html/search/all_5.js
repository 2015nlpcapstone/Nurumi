var searchData=
[
  ['finalize',['finalize',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_i_m_e___automata.html#a61aaf6f3f12c890dd33dfa063f6b5d5c',1,'kookmin::cs::fouram::nurumikeyboard::automata::IME_Automata']]],
  ['finger',['finger',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_i_m_e___automata.html#aa5f74d1b87cf3bc846356683010a1a13',1,'kookmin::cs::fouram::nurumikeyboard::automata::IME_Automata']]],
  ['firstjaeum_5fbokjaeum',['firstjaeum_bokjaeum',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_korean_cheon_ji_in.html#acc34b7b7f842472027aee3b4a271af1f',1,'kookmin::cs::fouram::nurumikeyboard::automata::KoreanCheonJiIn']]],
  ['five_5ffingers',['FIVE_FINGERS',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_nurumi_i_m_e.html#a5c0f60d26d9d5db8a8e3e411a3e953be',1,'kookmin::cs::fouram::nurumikeyboard::inputmethod::NurumiIME']]]
];
