var searchData=
[
  ['finalize',['finalize',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_i_m_e___automata_1_1_i_m_e___automata.html#a7eea949c02b8c221696e9b22cd287daa',1,'com::fouram::nurumikeyboard::IME_Automata::IME_Automata']]],
  ['finger',['finger',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_i_m_e___automata_1_1_i_m_e___automata.html#a0b7b586cd3f2d557861fc4798bb1e78f',1,'com::fouram::nurumikeyboard::IME_Automata::IME_Automata']]],
  ['firstjaeum_5fbokjaeum',['firstjaeum_bokjaeum',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_i_m_e___automata_1_1_automata__type___kor__1.html#ac7397649ad44d329e248c4aae3ea0c1a',1,'com::fouram::nurumikeyboard::IME_Automata::Automata_type_Kor_1']]],
  ['five_5ffingers',['FIVE_FINGERS',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_nurumi_i_m_e.html#a9b39dd4573a5446f50b56ae0f0beba4d',1,'com::fouram::nurumikeyboard::NurumiIME::NurumiIME']]],
  ['font_5fsize',['FONT_SIZE',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_m_keyboard_view.html#a23e5ec95ccc9a2521f46ce31484af10e',1,'com::fouram::nurumikeyboard::NurumiIME::MKeyboardView']]],
  ['fontsize',['fontSize',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_m_keyboard_view.html#a4e8a715c36ff3c2971a6f3dd31a72d09',1,'com::fouram::nurumikeyboard::NurumiIME::MKeyboardView']]]
];
