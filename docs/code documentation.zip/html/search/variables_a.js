var searchData=
[
  ['keyboardtypeflag',['keyboardTypeFlag',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_nurumi_i_m_e.html#adccb6cffa5d468babdb9d6fe8ec734ef',1,'kookmin::cs::fouram::nurumikeyboard::inputmethod::NurumiIME']]],
  ['kieuk',['KIEUK',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_korean.html#aac6143bd2ab107ab80377b50aacf3047',1,'kookmin::cs::fouram::nurumikeyboard::automata::Korean']]],
  ['kmap',['kMap',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_korean.html#a2e569e4b5f65a33de34e6655c70db974',1,'kookmin::cs::fouram::nurumikeyboard::automata::Korean']]],
  ['kor',['KOR',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_nurumi_i_m_e.html#a7290920c29fef26302a45b9a88c2c362',1,'kookmin::cs::fouram::nurumikeyboard::inputmethod::NurumiIME']]],
  ['korean',['korean',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1_automata_state_context.html#a1674b31cc712ad0b3233eb2e0ef280b5',1,'kookmin::cs::fouram::nurumikeyboard::automata::AutomataStateContext']]]
];
