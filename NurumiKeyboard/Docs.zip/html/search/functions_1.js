var searchData=
[
  ['changekeyboardtype',['changeKeyboardType',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_nurumi_i_m_e.html#a42ea346aed0dc581a4c059a0e00b1ce4',1,'com::fouram::nurumikeyboard::NurumiIME::NurumiIME']]],
  ['checkdirection',['checkDirection',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_m_keyboard_view.html#aa548466053ead7d81890a197df4e0665',1,'com::fouram::nurumikeyboard::NurumiIME::MKeyboardView']]],
  ['checktouchedcircle',['checkTouchedCircle',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_m_keyboard_view.html#ad7701634206a8ad8fb6ad5bc72fc39d1',1,'com::fouram::nurumikeyboard::NurumiIME::MKeyboardView']]],
  ['cho_5fseong_5fjaeum',['CHO_SEONG_JAEUM',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_i_m_e___automata_1_1_automata__type___kor__1.html#afbd9ce23aa20f0167cf7fbff22b7c909',1,'com::fouram::nurumikeyboard::IME_Automata::Automata_type_Kor_1']]],
  ['cho_5fseong_5fmoeum',['CHO_SEONG_MOEUM',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_i_m_e___automata_1_1_automata__type___kor__1.html#a83811ffc4a2967a660b4232cb70fbaec',1,'com::fouram::nurumikeyboard::IME_Automata::Automata_type_Kor_1']]],
  ['choseong_5fmoeum',['choseong_moeum',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_i_m_e___automata_1_1_automata__type___kor__1.html#aa8585f0bd4d89c2d8c05195d816eb4b3',1,'com::fouram::nurumikeyboard::IME_Automata::Automata_type_Kor_1']]]
];
