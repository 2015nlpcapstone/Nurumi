var searchData=
[
  ['ready_5fto_5fcommit_5ftext',['ready_to_commit_text',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_i_m_e___automata_1_1_automata__type___kor__3.html#ac4162cfdb513b67693bb5c0524380ed5',1,'com::fouram::nurumikeyboard::IME_Automata::Automata_type_Kor_3']]],
  ['recyclebitmap',['recycleBitmap',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_m_keyboard_view.html#ab83f53c002ebfb869a155306c0d2f6c0',1,'com::fouram::nurumikeyboard::NurumiIME::MKeyboardView']]],
  ['replace_5fto',['replace_to',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_i_m_e___automata_1_1_automata__type___kor__3.html#a9d9cfba0f2a4d62544d40e27a71a2dc0',1,'com::fouram::nurumikeyboard::IME_Automata::Automata_type_Kor_3']]],
  ['rightimg',['rightImg',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_m_keyboard_view.html#ae1f82cc38d6394ee0eb1db7c36ac1cbb',1,'com::fouram::nurumikeyboard::NurumiIME::MKeyboardView']]],
  ['ring_5f_5ffinger',['RING__FINGER',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_i_m_e___automata_1_1_i_m_e___automata.html#a12580f1399984b688fa50137d3e2a684',1,'com::fouram::nurumikeyboard::IME_Automata::IME_Automata']]]
];
