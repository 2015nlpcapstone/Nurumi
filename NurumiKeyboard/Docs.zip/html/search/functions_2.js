var searchData=
[
  ['dptopx',['dpToPx',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_m_keyboard_view.html#aad7006f959771d90a6b714e5b4c75bdf',1,'com::fouram::nurumikeyboard::NurumiIME::MKeyboardView']]]
];
