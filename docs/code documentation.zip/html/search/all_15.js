var searchData=
[
  ['vg',['vg',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_nurumi_i_m_e.html#a3ccbb1afd4aa28ecd9fc51c56074626a',1,'kookmin::cs::fouram::nurumikeyboard::inputmethod::NurumiIME']]],
  ['vowel',['Vowel',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1korean_character_1_1_vowel.html#aaec3ec154ba30ca8894a3c41b74aa479',1,'kookmin::cs::fouram::nurumikeyboard::automata::koreanCharacter::Vowel']]],
  ['vowel',['Vowel',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1automata_1_1korean_character_1_1_vowel.html',1,'kookmin::cs::fouram::nurumikeyboard::automata::koreanCharacter']]],
  ['vowel_2ejava',['Vowel.java',['../_vowel_8java.html',1,'']]]
];
