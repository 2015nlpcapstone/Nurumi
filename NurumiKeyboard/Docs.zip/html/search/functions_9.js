var searchData=
[
  ['mkeyboardview',['MKeyboardView',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_m_keyboard_view.html#a970fc12bcbc4830bea85945fd4909edd',1,'com.fouram.nurumikeyboard.NurumiIME.MKeyboardView.MKeyboardView(Context context, AttributeSet attrs)'],['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_m_keyboard_view.html#a565bb11cbc920cca01f533beb7468419',1,'com.fouram.nurumikeyboard.NurumiIME.MKeyboardView.MKeyboardView(Context context)']]],
  ['mode_5fenglish',['MODE_ENGLISH',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_i_m_e___automata_1_1_automata__type___eng.html#ac93bc5c277a48588c38c70987c3acd31',1,'com::fouram::nurumikeyboard::IME_Automata::Automata_type_Eng']]],
  ['mode_5fspecial',['MODE_SPECIAL',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_i_m_e___automata_1_1_automata__type___spc.html#a56d22825f38e3b9a359a14a1901a053f',1,'com::fouram::nurumikeyboard::IME_Automata::Automata_type_Spc']]],
  ['moeumbuffer_5fclear',['Moeumbuffer_clear',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_i_m_e___automata_1_1_automata__type___kor__1.html#aacd1291d4ea8ea62f26ab013237c2b94',1,'com::fouram::nurumikeyboard::IME_Automata::Automata_type_Kor_1']]],
  ['motioncheck',['motionCheck',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_m_keyboard_view.html#a657f24f9888d141266179c6dc971103f',1,'com::fouram::nurumikeyboard::NurumiIME::MKeyboardView']]]
];
