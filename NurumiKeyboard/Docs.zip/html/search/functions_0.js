var searchData=
[
  ['bok_5fjaeum',['BOK_JAEUM',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___kor__1.html#a23bd4d959ddfbb2cb84d795f361aa9df',1,'com::fouram::nurumikeyboard::NurumiIME::Automata_type_Kor_1']]],
  ['buffer_5fclean',['buffer_clean',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___kor__3.html#abbd174e552fc0b8877958da4ff2ef4ee',1,'com::fouram::nurumikeyboard::NurumiIME::Automata_type_Kor_3']]],
  ['buffer_5fclear',['buffer_clear',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___kor__1.html#abc6892991b6c891f1a248a11e23f7218',1,'com::fouram::nurumikeyboard::NurumiIME::Automata_type_Kor_1']]]
];
