var searchData=
[
  ['wisp_5fflare',['WISP_FLARE',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_i_m_e___automata_1_1_automata__type___kor__2.html#a852edf6cd728ce52bc3aacc0ea1cefbd',1,'com.fouram.nurumikeyboard.IME_Automata.Automata_type_Kor_2.WISP_FLARE()'],['../classcom_1_1fouram_1_1nurumikeyboard_1_1_i_m_e___automata_1_1_automata__type___kor__3.html#a71186133486a40efb0e75a1c7f590a06',1,'com.fouram.nurumikeyboard.IME_Automata.Automata_type_Kor_3.WISP_FLARE()']]]
];
