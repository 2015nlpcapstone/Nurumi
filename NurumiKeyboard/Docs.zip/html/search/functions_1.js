var searchData=
[
  ['changekeyboardtype',['changeKeyboardType',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_nurumi_i_m_e.html#a6eeafdb7296a1d39f53c3424802a5fc7',1,'com::fouram::nurumikeyboard::NurumiIME::NurumiIME']]],
  ['checkdirection',['checkDirection',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_m_keyboard_view.html#aa548466053ead7d81890a197df4e0665',1,'com::fouram::nurumikeyboard::NurumiIME::MKeyboardView']]],
  ['checktouchedcircle',['checkTouchedCircle',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_m_keyboard_view.html#ad7701634206a8ad8fb6ad5bc72fc39d1',1,'com::fouram::nurumikeyboard::NurumiIME::MKeyboardView']]],
  ['cho_5fseong_5fjaeum',['CHO_SEONG_JAEUM',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___kor__1.html#adcbb9d5337d3c191fa6f3d179596621b',1,'com::fouram::nurumikeyboard::NurumiIME::Automata_type_Kor_1']]],
  ['cho_5fseong_5fmoeum',['CHO_SEONG_MOEUM',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___kor__1.html#a2ba316eaaf8d4dda184bb94222231afe',1,'com::fouram::nurumikeyboard::NurumiIME::Automata_type_Kor_1']]],
  ['choseong_5fmoeum',['choseong_moeum',['../classcom_1_1fouram_1_1nurumikeyboard_1_1_nurumi_i_m_e_1_1_automata__type___kor__1.html#ad6c696cbac98f1c190c001f8488bf39b',1,'com::fouram::nurumikeyboard::NurumiIME::Automata_type_Kor_1']]]
];
