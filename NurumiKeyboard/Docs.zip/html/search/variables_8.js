var searchData=
[
  ['keyboardtypeflag',['keyboardTypeFlag',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_nurumi_i_m_e.html#adccb6cffa5d468babdb9d6fe8ec734ef',1,'kookmin::cs::fouram::nurumikeyboard::inputmethod::NurumiIME']]],
  ['kor',['KOR',['../classkookmin_1_1cs_1_1fouram_1_1nurumikeyboard_1_1inputmethod_1_1_nurumi_i_m_e.html#a7290920c29fef26302a45b9a88c2c362',1,'kookmin::cs::fouram::nurumikeyboard::inputmethod::NurumiIME']]]
];
